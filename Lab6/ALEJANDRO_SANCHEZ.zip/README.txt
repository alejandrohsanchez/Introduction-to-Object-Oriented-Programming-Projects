Problem 1
compile: g++ q1.cpp -o q1
run: ./q1

Problem 2
compile: g++ q2.cpp -o q2
run: ./q2

Problem 3
compile: g++ q3.cpp -o q3
run: ./q3	

Problem 4
compile: g++ q4.cpp -o q4
run: ./q4

Problem 5
compile: g++ q5.cpp -o q5
run: ./q5

Problem 6
compile: g++ q6.cpp -o q6
run: ./q6